-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2022 at 08:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Aid` varchar(35) NOT NULL,
  `Apass` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Aid`, `Apass`) VALUES
('admin', '123456'),
('c2vyas@gmail.com', '123456'),
('cyan', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `examans`
--

CREATE TABLE `examans` (
  `EAnsID` int(50) NOT NULL,
  `ExamID` int(10) NOT NULL,
  `Senrl` varchar(50) NOT NULL,
  `Sname` varchar(50) NOT NULL,
  `Ans1` mediumtext NOT NULL,
  `Ans2` mediumtext NOT NULL,
  `Ans3` mediumtext NOT NULL,
  `Ans4` mediumtext NOT NULL,
  `Ans5` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examans`
--

INSERT INTO `examans` (`EAnsID`, `ExamID`, `Senrl`, `Sname`, `Ans1`, `Ans2`, `Ans3`, `Ans4`, `Ans5`) VALUES
(1, 1231, '1001', 'Vishal Mathur', 'A', 'B', 'C', 'D', 'E'),
(2, 1232, '1002 ', 'Harsh Jain', 'C', 'A', 'B', 'A', 'C'),
(3, 1233, '1003 ', 'Nihal Kumar', 'C', 'B', 'B', 'A', 'C'),
(4, 1234, '1004 ', 'Kajal Mathur', 'A', 'B', 'C', 'D', 'E'),
(5, 1235, '1005', 'Kunal Singh', 'A', 'A', 'A', 'A', 'A'),
(6, 1236, '1006', 'Rohan Pal', 'A', 'C', 'B', 'B', 'A'),
(7, 1237, '1007', 'Priya Danjal', 'A', 'B', 'A', 'B', 'A'),
(8, 1238, '1008', 'Neelam Kumari', 'A', 'B', 'A', 'B', 'A'),
(9, 1239, '1009', 'Seema Rathor', 'A', 'B', 'A', 'B', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `examdetails`
--

CREATE TABLE `examdetails` (
  `ExamID` int(50) NOT NULL,
  `ExamName` varchar(50) NOT NULL,
  `Q1` varchar(10000) NOT NULL,
  `Q2` varchar(10000) NOT NULL,
  `Q3` varchar(10000) NOT NULL,
  `Q4` varchar(10000) NOT NULL,
  `Q5` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examdetails`
--

INSERT INTO `examdetails` (`ExamID`, `ExamName`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`) VALUES
(1, 'HTML', 'What is the previous version of HTML, prior to HTML5?', ' What does HTML stand for?', 'Who is making the Web standards?', 'Choose the correct HTML element for the largest heading:', 'What is the correct HTML element for inserting a line break?'),
(2, ' PHP', ' What does PHP stand for?', 'PHP server scripts are surrounded by delimiters, which?', 'How do you write \"Hello World\" in PHP', ' All variables in PHP start with which symbol?', 'What is the correct way to end a PHP statement?'),
(3, 'SQL', 'What does SQL stand for?', 'Which SQL statement is used to extract data from a database?', 'Which SQL statement is used to update data in a database?', 'Which SQL statement is used to delete data from a database?', 'Which SQL statement is used to insert new data in a database?'),
(4, 'JavaScript', 'Inside which HTML element do we put the JavaScript?', 'What is the correct JavaScript syntax to change the content of the HTML element below?\r\n\r\n\r\n<p id=\"demo\">This is a demonstration.</p>', 'Where is the correct place to insert a JavaScript?', 'What is the correct syntax for referring to an external script called \"xxx.js\"?', 'The external JavaScript file must contain the <script> tag. True or False?'),
(5, 'Bootstrap ', 'Bootstrap 3 is mobile-first. False or  True?', 'Which class provides a responsive fixed width container?', ' Which class provides a full width container, spanning the entire width of the viewport?', 'The Bootstrap grid system is based on how many columns?', 'Which class adds zebra-stripes to a table?'),
(6, 'jQuery', ' jQuery uses CSS selectors to select elements?  True or False?', 'Which sign does jQuery use as a shortcut for jQuery?', 'Look at the following selector: $(\"div\"). What does it select?', 'Is jQuery a library for client scripting or server scripting?', 'Is it possible to use jQuery together with AJAX?');

-- --------------------------------------------------------

--
-- Table structure for table `facutlytable`
--

CREATE TABLE `facutlytable` (
  `FID` int(10) NOT NULL,
  `FName` varchar(50) NOT NULL,
  `Addrs` text NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `City` varchar(10) NOT NULL,
  `Pass` varchar(10) NOT NULL,
  `PhNo` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facutlytable`
--

INSERT INTO `facutlytable` (`FID`, `FName`, `Addrs`, `Gender`, `City`, `Pass`, `PhNo`) VALUES
(101, 'Dr. Manish Shrimali', 'Udaipur', 'Male', 'Udaipur', '123456', 1234567890),
(102, 'Mansi Nagar', 'Udaipur', 'Female', 'Udaipur', '123456', 1234567890),
(103, 'Dr. Priyanka Soni', 'Udaipur', 'Female', 'Udaipur', '123456', 1234567890),
(104, 'Dr. Gaurav Garg', 'Udaipur', 'Male', 'Udaipur', '123456', 1234567890),
(105, 'Dr. Bharat Singh Deora', 'Udaipur', 'Male', 'Udaipur', '123456', 1234567890),
(106, 'Dilip Choudhary', 'Udaipur', 'Male', 'Udaipur', '123456', 1234567890);

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `GuEid` varchar(35) NOT NULL,
  `Gname` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`GuEid`, `Gname`) VALUES
('abc@gmail.com', 'Chayan Shrimali'),
('c3vyas75@gmail.com', 'Cyan'),
('abc@gmail.com', 'Nisha Deora');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `Query` text NOT NULL,
  `Ans` text NOT NULL,
  `Eid` varchar(35) NOT NULL,
  `Qid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`Query`, `Ans`, `Eid`, `Qid`) VALUES
('Can I use Visual Studio instead of other code editor? ', 'Yes. you may use according to your use.', 'a1@gmail.com', 1),
('Sir I have problem in a program...', 'Don\'t worry we will be help you with.', 'a2@gmail.com', 2),
('Sir May I take leave for Today?', 'yes, you may									', 'a3@gmail.com', 3),
('Can I do M.Tech? ', 'Ofcourse.							', 'a4@gmail.com', 4),
('Can I do BCA.', 'You May', 'a5@gmail.com', 5),
('Can I do M.SC. ?\r\n', 'Yes, First you complete BSC.							', 'a6@gmail.com', 6);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `RsID` bigint(20) NOT NULL,
  `Eno` varchar(20) NOT NULL,
  `Ex_ID` int(10) NOT NULL,
  `Marks` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`RsID`, `Eno`, `Ex_ID`, `Marks`) VALUES
(2377, '1001', 3, 'Pass'),
(2378, '1002', 3, 'Fail'),
(2379, '1003', 3, 'Pass'),
(2380, '1004', 7, 'Fail'),
(2382, '1001', 1231, 'Pass'),
(2383, '1006', 1236, 'Under Progress');

-- --------------------------------------------------------

--
-- Table structure for table `studenttable`
--

CREATE TABLE `studenttable` (
  `Eno` bigint(20) NOT NULL,
  `FName` varchar(30) NOT NULL,
  `LName` varchar(30) NOT NULL,
  `FaName` varchar(30) NOT NULL,
  `Addrs` text NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `Course` varchar(20) NOT NULL,
  `DOB` date NOT NULL,
  `PhNo` bigint(10) NOT NULL,
  `Pass` varchar(20) NOT NULL,
  `Eid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studenttable`
--

INSERT INTO `studenttable` (`Eno`, `FName`, `LName`, `FaName`, `Addrs`, `Gender`, `Course`, `DOB`, `PhNo`, `Pass`, `Eid`) VALUES
(1001, 'Vishal', 'mathur', 'Vinod singh mathur', 'Banswara', 'male', 'MCA', '1996-07-12', 1234567890, '123456', 'vishal@ics.com'),
(1002, 'Harsh', 'Jain', 'Pardeep Jain', 'Udaipur', 'Male', 'MCA', '1996-07-16', 1234567890, '123456', 'harsh@ics.com'),
(1003, 'Nihal', 'Kumar', 'Ram Kumar', 'Nathdwara', 'Male', 'BCA', '2000-08-05', 1234567890, '123456', 'nihal@ics.com'),
(1004, 'Kajal', 'Mathur', 'Arjun Mathur', 'Dabok', 'Female', 'MSC', '1996-02-10', 1234567890, '123456', 'kajal@ics.com'),
(1005, 'Kunal', 'Singh', 'Ram Singh', 'Kanor', 'Male', 'PG', '1996-02-03', 1234567890, '123456', 'test@ics.com'),
(1006, 'Rohan', 'Pal', 'Nareder singh', 'Balicha', 'Male', 'BCA', '1996-01-01', 1234567890, '123456', 'rohan@ics.com'),
(1007, 'Priya', 'Danjal', 'Raj Danjal', 'Udaipur', 'Female', 'BSC', '1994-05-04', 1234567890, '123456', 'priya@ics.com'),
(1008, 'Neelam', 'Kumari', 'Purohit Sharma', 'Mavli', 'Female', 'MSC', '1995-08-25', 1234567890, '123456', 'neelam@ics.com'),
(1009, 'Seema', 'Rathor', 'Bhawani Singh Ji', 'Udaipur', 'Female', 'MCA', '1996-05-02', 1234567890, '123456', 'seema@CC.com');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `V_id` int(10) NOT NULL,
  `V_Title` varchar(50) NOT NULL,
  `V_Url` longtext NOT NULL,
  `V_Remarks` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='This table is used to store videos info.';

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`V_id`, `V_Title`, `V_Url`, `V_Remarks`) VALUES
(1, 'HTML', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/uDIL-GguPOw?rel=0&amp;showinfo=0\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', 'html complete layout'),
(2, 'CSS Grid ', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/HgwCeNVPlo0?rel=0&amp;showinfo=0\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', 'How to create website layouts using CSS grid'),
(3, 'JQuery', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/BWXggB-T1jQ\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', 'JQuery Tutorial:\r\nQuery is a cross-platform JavaScript library designed to simplify the client-side scripting of HTML. It is free, open-source software using the permissive MIT License.'),
(4, 'JSON ', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/JuFdz8f-cT4\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', 'JavaScript Object Notation or JSON is an open-standard file format that uses human-readable text to transmit data objects consisting of attributeâ€“value pairs and array data types (or any other serializable value).\r\nIt is a very common data format used for asynchronous browserâ€“server communication, including as a replacement for XML in some AJAX-style systems.\r\nJSON is a language-independent data format.\r\nIt was derived from JavaScript, ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Aid`);

--
-- Indexes for table `examans`
--
ALTER TABLE `examans`
  ADD PRIMARY KEY (`EAnsID`);

--
-- Indexes for table `examdetails`
--
ALTER TABLE `examdetails`
  ADD PRIMARY KEY (`ExamID`),
  ADD UNIQUE KEY `ExamName` (`ExamName`);

--
-- Indexes for table `facutlytable`
--
ALTER TABLE `facutlytable`
  ADD PRIMARY KEY (`FID`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`Gname`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`Qid`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`RsID`);

--
-- Indexes for table `studenttable`
--
ALTER TABLE `studenttable`
  ADD PRIMARY KEY (`Eno`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`V_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `examans`
--
ALTER TABLE `examans`
  MODIFY `EAnsID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `examdetails`
--
ALTER TABLE `examdetails`
  MODIFY `ExamID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `facutlytable`
--
ALTER TABLE `facutlytable`
  MODIFY `FID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `Qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `RsID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2384;

--
-- AUTO_INCREMENT for table `studenttable`
--
ALTER TABLE `studenttable`
  MODIFY `Eno` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146891663;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `V_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
