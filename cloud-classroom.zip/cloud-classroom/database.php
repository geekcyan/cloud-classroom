<?php

$server = "localhost";
$user = "root";
$passdb = "";
$db = "my_db";
$connect = mysqli_connect( $server, $user, $passdb, $db )or die( "Connection Error" );

?>