<?php
session_start();
?>
<?php
$_SESSION["sidx"]=="";

header('Location:index');
?>