<?php
session_start();
?>
<?php
$_SESSION["fidx"]=="";

header('Location:index.php');
?>