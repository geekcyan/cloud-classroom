<?php
session_start();
?>
<?php
$_SESSION["umail"]=="";


header('Location:index.php');
?>